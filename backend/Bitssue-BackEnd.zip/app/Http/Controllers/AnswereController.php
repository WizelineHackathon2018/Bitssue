<?php

namespace App\Http\Controllers;

use App\Answere;
use Illuminate\Http\Request;

class AnswereController extends Controller
{
    public function store(Request $request)
    {
        
    }

    public function update(Request $request)
    {
        
    }

    public function destroy(Answere $answere)
    {
        
    }
}
