<?php

namespace App\Http\Controllers;

use App\Team;
use Illuminate\Http\Request;

class TeamController extends Controller
{

    public function index()
    {
        
    }

    public function store(Request $request)
    {
        
    }

    public function update(Request $request, Team $team)
    {
        
    }

    public function destroy(Team $team)
    {
        
    }
}
