<?php

namespace App\Http\Controllers;

use App\Member;
use Illuminate\Http\Request;

class MemberController extends Controller
{

    public function index()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    
    public function show(Member $member)
    {
        //
    }

    public function update(Request $request, Member $member)
    {
        //
    }

}
